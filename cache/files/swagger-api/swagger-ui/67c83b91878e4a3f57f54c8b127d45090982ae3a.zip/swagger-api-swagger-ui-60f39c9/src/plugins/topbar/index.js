import Topbar from "./topbar"
import Logo from "./logo"

export default function () {
  return {
    components: {
      Topbar,
      Logo
    }
  }
}
