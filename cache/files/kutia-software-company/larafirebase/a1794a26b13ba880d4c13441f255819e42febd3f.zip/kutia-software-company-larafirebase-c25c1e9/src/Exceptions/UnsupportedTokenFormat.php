<?php

namespace Kutia\Larafirebase\Exceptions;

use Exception;

class UnsupportedTokenFormat extends Exception
{
    // 
}
