<?php

if (!function_exists('larafirebase')) {
    function larafirebase()
    {
        return app('larafirebase');
    }
}
