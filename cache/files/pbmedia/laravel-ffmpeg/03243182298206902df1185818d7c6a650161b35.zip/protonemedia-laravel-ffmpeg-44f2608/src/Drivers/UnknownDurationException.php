<?php

namespace ProtoneMedia\LaravelFFMpeg\Drivers;

use Exception;

class UnknownDurationException extends Exception
{
}
