<?php

namespace ProtoneMedia\LaravelFFMpeg\Exporters;

use Exception;

class NoFormatException extends Exception
{
}
